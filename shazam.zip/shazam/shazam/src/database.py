"""
Song database: wraps the custom hash table to index and store fingerprints.

Refer to GUIDE.md, Milestone 3 for detailed instructions.
"""

import json
import os

from src.fingerprint import fingerprint_audio
from src.hash_table import HashTable
from src.utils import load_audio


class SongDatabase:
    def __init__(self):
        self.table = HashTable()
        self.song_names = {}
        self._next_id = 0

    def get_song_name(self, song_id):
        return self.song_names.get(song_id, f"Unknown (id={song_id})")

    def index_song(self, filepath, song_name=None):
        audio, sr = load_audio(filepath)  # desempaca la tupla
        fingerprints = fingerprint_audio(audio, sample_rate=sr)
        song_id = self._next_id
        self._next_id += 1

        if song_name is None:
            song_name = os.path.splitext(os.path.basename(filepath))[0]

        self.song_names[song_id] = song_name

        for hash_val, time_offset in fingerprints:
            self.table.insert(hash_val, (song_id, time_offset))

        print(f"Indexed song: {song_name} (ID: {song_id})")
        return song_id

    def index_directory(self, directory):
        files = os.listdir(directory)
        files = [f for f in files if f.lower().endswith(".wav")]
        files.sort()
        for filename in files:
            filepath = os.path.join(directory, filename)
            self.index_song(filepath)

    def save(self, filepath):
        entries = []
        for bucket in self.table._buckets:
            for key, (song_id, time_offset) in bucket:
                entries.append([int(key), int(song_id), int(time_offset)])
        data = {
            "song_names": {str(k): v for k, v in self.song_names.items()},
            "next_id": self._next_id,
            "capacity": self.table.capacity(),  # FIX: _capacity() -> capacity()
            "entries": entries
        }
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        with open(filepath, "w") as f:
            json.dump(data, f)

    @classmethod
    def load(cls, filepath):
        with open(filepath, "r") as f:
            data = json.load(f)
        db = cls()
        db.song_names = {int(k): v for k, v in data["song_names"].items()}
        db._next_id = data["next_id"]
        db.table = HashTable(capacity=data["capacity"])
        for key, song_id, time_offset in data["entries"]:
            db.table.insert(key, (song_id, time_offset))
        return db