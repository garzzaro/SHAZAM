"""
Custom hash table with separate chaining.
"""

import math


class HashTable:
    DEFAULT_CAPACITY = 10007

    def __init__(self, capacity=None):
        self._capacity = capacity or self.DEFAULT_CAPACITY
        self._buckets = [[] for _ in range(self._capacity)]
        self._size = 0

    # ------------------------------------------------------------------ #
    # Hash function
    # ------------------------------------------------------------------ #

    def _hash(self, key):
        return (int(key) * 2654435761) % self._capacity

    # ------------------------------------------------------------------ #
    # Core operations
    # ------------------------------------------------------------------ #

    def insert(self, key, value):
        index = self._hash(key)
        self._buckets[index].append((key, value))
        self._size += 1
        if self.load_factor() > 0.75:
            self._resize()

    def lookup(self, key):
        index = self._hash(key)
        return [v for k, v in self._buckets[index] if k == key]

    # ------------------------------------------------------------------ #
    # Size & statistics
    # ------------------------------------------------------------------ #

    def size(self):
        return self._size

    def capacity(self):
        return self._capacity

    def load_factor(self):
        return self._size / self._capacity

    def stats(self):
        non_empty = [b for b in self._buckets if b]
        chain_lengths = [len(b) for b in non_empty]
        return {
            "capacity": self._capacity,
            "size": self._size,
            "load_factor": round(self.load_factor(), 4),
            "empty_buckets": self._capacity - len(non_empty),
            "max_chain_length": max(chain_lengths) if chain_lengths else 0,
            "avg_chain_length": round(sum(chain_lengths) / len(chain_lengths), 4) if chain_lengths else 0.0,
        }

    # ------------------------------------------------------------------ #
    # Resizing
    # ------------------------------------------------------------------ #

    @staticmethod
    def _next_prime(n):
        if n <= 2:
            return 2
        candidate = n if n % 2 != 0 else n + 1
        while True:
            is_prime = all(candidate % i != 0 for i in range(3, int(math.sqrt(candidate)) + 1, 2))
            if is_prime:
                return candidate
            candidate += 2

    def _resize(self):
        new_capacity = self._next_prime(self._capacity * 2)
        old_buckets = self._buckets
        self._capacity = new_capacity
        self._buckets = [[] for _ in range(self._capacity)]
        self._size = 0
        for bucket in old_buckets:
            for key, value in bucket:
                self.insert(key, value)
    