from src.database import SongDatabase
from src.recognize import record_and_recognize
from src.utils import load_audio

db = SongDatabase()
db.index_directory("songs/")

best_song_name, best_count, all_scores = record_and_recognize(db)

print(f"Best match: {best_song_name} (score={best_count})")
print("All scores:")
for song_name, score in all_scores.items():
    print(f"  {song_name}: {score}")



